<template>
  <footer class="black-footer">
    <div class="container">
      <p class="text">Litclub© 2023 </p>
    </div>
  </footer>
</template>

<style scoped>
.black-footer {
  background-color: #0d0d0d;
  color: #fff;
  padding: 6em 2em 0 5em;
  height:9em;
}

.container {
  max-width: 100vw;
}

.text {
  text-align: right;
  font-family: 'Tinos', serif;
  font-size:1.5rem;
}
</style>
